package stepImplementations;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.After;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class BDDLoginTest {
	
	WebDriver driver;
	
	@Given("^user is on the login page$")
	
	public void user_is_on_the_login_page() {
		System.out.println("User is in the login page");
		
		System.setProperty("webdriver.chrome.driver", "/home/pritam/Downloads/chromedriver/chromedriver_linux64/chromedriver");
		driver= new ChromeDriver();
		driver.get("https://opensource-demo.orangehrmlive.com");
		
	}
	/*
	@When("^user enters correct username and password$")
	
	public void user_enters_correct_username_and_password() throws InterruptedException
	{
		System.out.println("User enters correct username and password");
		driver.findElement(By.xpath("//*[@id=\"txtUsername\"]"));
		driver.findElement(By.xpath("//*[@id=\"txtPassword\"]"));
		driver.findElement(By.xpath("//*[@id=\"btnLogin\"]")).click();
		Thread.sleep(5000);
	}
	
	*/
	@When("^user enters username (.*)$")
	public void user_enters_username(String username) {
		System.out.println("Testing: "+ username);
		driver.findElement(By.xpath("//*[@id=\"txtUsername\"]")).sendKeys(username);
	}
	
	@And("^user enters password (.*)$")
	public void user_enters_password(String password) {

		driver.findElement(By.xpath("//*[@id=\"txtPassword\"]")).sendKeys(password);
		
	}
	
	@Then("^user gets confirmation$")
	
	public void user_gets_confirmation() throws InterruptedException
	{
		System.out.println("User gets confirmation");
		driver.findElement(By.xpath("//*[@id=\"btnLogin\"]")).click();
		Thread.sleep(5000);
	}
	
	@After
	public void tearDown() {
		
		driver.quit();
	}

}
